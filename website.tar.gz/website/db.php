<?php_
$link = mysqli_connect("localhost","root", "", "CPSC471");
if(!$link)
{
	die('Cannot connect'. mysqli_error($link);
	
}

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "CPSC471";





>
